import { Component, OnInit } from '@angular/core';
declare var jquery:any;
declare var $ :any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  title="carasoul"
  images=["https://dummyimage.com/1366x455/ff3333/FFF&text=First","https://dummyimage.com/1366x455/006600/FFF&text=Second","https://dummyimage.com/1366x455/993300/FFF&text=Third","https://dummyimage.com/1366x455/cc0099/FFF&text=Fourth","https://dummyimage.com/1366x455/3366cc/FFF&text=Fifth"];
  number = [0,1,2,3,4];
  constructor() { }
  ngOnInit() {
    for(let i = 0; i < 5; i++) {
      // console.log(i);
    }

    $(document).ready(function(){
      $("#myDIV").addClass("active")
      $(".carousel-indicators>li:first-child").addClass("active");
    });
    }
    
}
